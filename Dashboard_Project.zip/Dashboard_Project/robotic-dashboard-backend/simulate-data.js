// simulate-data.js
import RobotData from "./models/RobotData);";