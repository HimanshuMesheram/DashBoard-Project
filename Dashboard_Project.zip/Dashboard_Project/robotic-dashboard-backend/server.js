// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/robotic-dashboard', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
  useFindAndModify: false,
});

const RobotData = mongoose.model('RobotData', {
  batteryLevel: Number,
  operationalStatus: String,
  activityLogs: [String],
});

app.get('/api/data', async (req, res) => {
  const data = await RobotData.findOne().exec();
  res.json(data);
});

app.post('/api/data', async (req, res) => {
  const data = new RobotData(req.body);
  await data.save();
  res.json(data);
});

app.listen(3001, () => {
  console.log('Server is running on port 3001');
});