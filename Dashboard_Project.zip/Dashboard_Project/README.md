
  # Robotic System Dashboard

## Overview
This project is a dashboard for monitoring a robotic system. It displays real-time and historical data such as battery level, operational status, and recent activity logs. The dashboard is developed using HTML5, CSS3, Bootstrap, and JavaScript.

## What's Included 📦

- Dashboard
  - Analytics
- Accounts
  - Account Settings
- Authentications
  - Login
  - Register
  - Forgot Password


## Installation
1. **Node.js**: Install Node.js from [here](https://nodejs.org/).

2. **Dependencies**: After installing Node.js, navigate to the project directory in your terminal and run the following command to install dependencies:
   ```bash
   npm install

Usage
Start the Server: Run the following command to start the server:

bash
Copy code
node server.js
This will start the server at http://localhost:3000.

View the Dashboard: Open a web browser and navigate to http://localhost:3000 to view the dashboard.
                           
                                       OR
You can Run **index.html** file from html folder

**Dependencies**
Node.js
Express
Mongoose
Bootstrap
Chart.js

**Folder Structure**
server.js: Node.js server file.
db.js: MongoDB connection file.
roboticSystem.js: Mongoose model for robotic system data.
public/: Directory containing static files (HTML, CSS, JavaScript).
public/index.html: HTML file for the dashboard.
public/styles.css: CSS file for styling.
public/scripts.js: JavaScript file for client-side logic.
public/chart.js: JavaScript file for Chart.js setup.


**Development**
Editor: Visual Studio Code (VS Code) is used as the primary editor for development.
Files: HTML, CSS, and JavaScript files are located in the public/ directory.
